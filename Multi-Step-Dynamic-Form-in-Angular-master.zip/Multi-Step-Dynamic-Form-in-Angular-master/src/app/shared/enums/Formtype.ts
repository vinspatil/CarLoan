export enum Formtype {
    basic = 'basic',
    contact = 'contact',
    other = 'other'
}
